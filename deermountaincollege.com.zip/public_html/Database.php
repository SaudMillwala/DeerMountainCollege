<?php
    $host = 'localhost';
    $user = 'u361717034_joathuni';
    $dbname   = 'u361717034_deermountain';
    $password = '1234567_Joath_CS';
    $dsn = 'mysql:host='. $host .';dbname='. $dbname;
    $pdo = new PDO($dsn, $user, $password);
?>
